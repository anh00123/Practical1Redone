// GUI and main program for the Training Record
package com.stir.cscu9t4practical1;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.lang.Number;


public class TrainingRecordGUI extends JFrame implements ActionListener {

    private JTextField name = new JTextField(30);
    private JTextField day = new JTextField(2);
    private JTextField month = new JTextField(2);
    private JTextField year = new JTextField(4);
    private JTextField hours = new JTextField(2);
    private JTextField mins = new JTextField(2);
    private JTextField secs = new JTextField(2);
    private JTextField dist = new JTextField(4);

    // added 7 new test fields to maintain readability and clarity these are come with buttons
    private JTextField activity = new JTextField(6);
    private JTextField where = new JTextField(6);
    private JTextField repetition = new JTextField(6);
    private JTextField recovery = new JTextField(5);
    private JTextField terrain = new JTextField(5);
    private JTextField speed = new JTextField(5);


    //labels for the text boxes
    private JLabel labwhere = new JLabel(" Where:");
    private JLabel labrep = new JLabel("Repetition:");
    private JLabel labrec = new JLabel("Recovery Time:");
    private JLabel labter = new JLabel("Terrain:");
    private JLabel labsp = new JLabel("Speed:");

    private JLabel laba = new JLabel(" Activity:");
    private JLabel labn = new JLabel(" Name:");
    private JLabel labd = new JLabel(" Day:");
    private JLabel labm = new JLabel(" Month:");
    private JLabel laby = new JLabel(" Year:");
    private JLabel labh = new JLabel(" Hours:");
    private JLabel labmm = new JLabel(" Mins:");
    private JLabel labs = new JLabel(" Secs:");
    private JLabel labdist = new JLabel(" Distance (km):");
    private JButton addR = new JButton("Add");


    private JButton lookUpByDate = new JButton("Look Up");
    private JButton findAllByDate = new JButton("Find All by Date"); //finds all the athletes on a given date
    private JButton findRunnerAll = new JButton("Find Names"); //finds the names of athletes
    private JButton clearInputs = new JButton("Remove Entry"); //removes the entries ona given date with name




    private TrainingRecord myAthletes = new TrainingRecord();

    private JTextArea outputArea = new JTextArea(5, 50);

    public static void main(String[] args) {
        TrainingRecordGUI applic = new TrainingRecordGUI();
    } // main

    // set up the GUI
    public TrainingRecordGUI() {
        super("Training Record");
        setLayout(new FlowLayout());
        add(labn);
        add(name);
        name.setEditable(true);
        add(labd);
        add(day);
        day.setEditable(true);
        add(labm);
        add(month);
        month.setEditable(true);
        add(laby);
        add(year);
        year.setEditable(true);
        add(labh);
        add(hours);
        hours.setEditable(true);
        add(labmm);
        add(mins);
        mins.setEditable(true);
        add(labs);
        add(secs);
        secs.setEditable(true);
        add(labdist);
        add(dist);


        add(laba);
        add(activity);
        activity.setEditable(true);

        add(labwhere);
        add(where);
        where.setEditable(true);

        add(labrep);
        add(repetition);
        repetition.setEditable(true);

        add(labrec);
        add(recovery);
        recovery.setEditable(true);

        add(labter);
        add(terrain);
        terrain.setEditable(true);

        add(labsp);
        add(speed);
        speed.setEditable(true);




        dist.setEditable(true);
        add(addR);
        addR.addActionListener(this);
        add(lookUpByDate);
        lookUpByDate.addActionListener(this);
        add(findAllByDate);
        findAllByDate.addActionListener(this);

        add(findRunnerAll);
        findRunnerAll.addActionListener(this);

        add(clearInputs);
        clearInputs.addActionListener(this);

        add(outputArea);
        outputArea.setEditable(false);
        setSize(720, 300);
        setVisible(true);
        blankDisplay();

        findAllByDate.setEnabled(false);
        lookUpByDate.setEnabled(false);
        findRunnerAll.setEnabled(false);
        clearInputs.setEnabled(false);

        // To save typing in new entries while testing, uncomment
        // the following lines (or add your own test cases)

    } // constructor

    // listen for and respond to GUI events
    public void actionPerformed(ActionEvent event) {
        String message = "";
        if (event.getSource() == addR) {
            message = addEntry("generic");
        }
        if (event.getSource() == lookUpByDate) {

            message = lookupEntry();
        }

        if (event.getSource() == findAllByDate)
        {
            message = findAllByDate(); //finds all athletes with entries on a given date
        }
        if (event.getSource() == findRunnerAll)
        {
            message = findRunnerAll(); //finds the name of an athlete
        }

        if(event.getSource() == clearInputs)
        {
            message = removeEntry(); //removes the entry
        }

        //clears the text field
        where.setText("");
        repetition.setText("");
        recovery.setText("");
        terrain.setText("");
        speed.setText("");


        outputArea.setText(message);
        blankDisplay();
    } // actionPerformed

    /*

    add Entry validates for accepting different values
    and then proceeds to add the entry

     */

    public String addEntry(String what) {
        String message = "Record added\n";
        boolean isInt = true;
        char[] swimSearch = {'s','w', 'm'}; //searches for the character within
        char[] runSearch = {'r', 'u'};
        char[] cycleSearch = {'c', 'y'};
        if (name.getText().equals("")) //checks if the name test box is empty
        {
            message = "Insert a Name\n";
        } else {
            String n = name.getText();

            try {
                Integer.parseInt(month.getText());
                Integer.parseInt(day.getText());
                Integer.parseInt(year.getText());
                Integer.parseInt(hours.getText());
                Integer.parseInt(mins.getText());
                Integer.parseInt(secs.getText());
                java.lang.Float.parseFloat(dist.getText());

                // return an int as a string

            } catch (NumberFormatException e) {
                message = "Day, month, year must be an integer";
                isInt = false;
            }

            /*
            if the values are an int then it sets it all to a string
             */
            if (isInt) {
                int m = Integer.parseInt(month.getText());
                int d = Integer.parseInt(day.getText());
                int y = Integer.parseInt(year.getText());
                float km = java.lang.Float.parseFloat(dist.getText());
                int h = Integer.parseInt(hours.getText());
                int mm = Integer.parseInt(mins.getText());
                int s = Integer.parseInt(secs.getText());


                //checks if the inputs are out of bounds
                if (mm > 59 || s > 59 || d > 31 || m > 12 || mm < 0 || d <= 0 || y <= 0 || km < 0 || h < 0) {
                    return "Input values in the correct format, e.g minutes cant be more than 59 or less than 0";
                }

                //checks if the an athlete has already been stored in a given date with their name
                if (myAthletes.findAthlete(n, d, m, y)) {
                    return n + " has already completed an activity";
                }
                else
                    {
                    if (activity.getText().equals("")) //checks if the activity text box is empty
                    {
                        message = "Please input an activity (cycled, ran, swam)";
                    }


                    //scans the text input for the specific character
                    for (int i = 0; i < activity.getText().length(); i++) {
                        char ch = activity.getText().charAt(i);
                        if (swimSearch[i] == ch) {


                            if (where.getText().equals("")) {
                                message = "Please add a location";
                            } else {
                                String act = activity.getText();
                                String wher = where.getText();
                                SwimEntry swim = new SwimEntry(n, d, m, y, h, mm, s, km, wher, act);
                                myAthletes.addEntry(swim);
                                System.out.println("Adding " + what + " entry to the records");

                                findAllByDate.setEnabled(true);
                                lookUpByDate.setEnabled(true);
                                findRunnerAll.setEnabled(true);
                                clearInputs.setEnabled(true);
                            }

                        }
                        break;
                    }

                    //same concept as the SwimEntry
                    for (int i = 0; i < activity.getText().length(); i++) {
                        char ch = activity.getText().charAt(i);
                        if (runSearch[i] == ch) {


                            if (repetition.getText().equals("") && recovery.getText().equals("")) {
                                message = "Please add a repetition and recovery value";
                            } else {
                                String act = activity.getText();
                                int rep = Integer.parseInt(repetition.getText());
                                int rec = Integer.parseInt(recovery.getText());
                                SprintEntry ran = new SprintEntry(n, d, m, y, h, mm, s, km, rep, rec, act);
                                myAthletes.addEntry(ran);
                                System.out.println("Adding " + what + " entry to the records");
                                findAllByDate.setEnabled(true);
                                lookUpByDate.setEnabled(true);
                                findRunnerAll.setEnabled(true);
                                clearInputs.setEnabled(true);
                            }

                        }
                        break;
                    }

                    //same concept as the SwimEntry
                    for (int i = 0; i < activity.getText().length(); i++) {
                        char ch = activity.getText().charAt(i);
                        if (cycleSearch[i] == ch) {


                            if (terrain.getText().equals("") && speed.getText().equals("")) {
                                message = "Please add a terrain and repetition";
                            }
                            else
                                {
                                String act = activity.getText();
                                String ter = terrain.getText();
                                String sp = speed.getText();
                                CycleEntry cycle = new CycleEntry(n, d, m, y, h, mm, s, km, ter, sp, act);
                                myAthletes.addEntry(cycle);
                                System.out.println("Adding " + what + " entry to the records");
                                findAllByDate.setEnabled(true);
                                lookUpByDate.setEnabled(true);
                                findRunnerAll.setEnabled(true);
                                clearInputs.setEnabled(true);

                            }


                        }
                        break;
                    }


                }

            }


        }
        return message;
    }


    public String removeEntry() //removes the entry based on date and name
    {
        int m = Integer.parseInt(month.getText());
        int d = Integer.parseInt(day.getText());
        int y = Integer.parseInt(year.getText());
        String n = name.getText();
        myAthletes.removeEntry(n,d,m,y);
        System.out.println("Entry removed");

        if(myAthletes.getNumberOfEntries() == 0) //disables buttons if there are no entries
        {
            findAllByDate.setEnabled(false);
            lookUpByDate.setEnabled(false);
            findRunnerAll.setEnabled(false);
            clearInputs.setEnabled(false);
        }

        return "Entry Removed";
    }

    public String lookupEntry() {

            int m = Integer.parseInt(month.getText());
            int d = Integer.parseInt(day.getText());
            int y = Integer.parseInt(year.getText());
            outputArea.setText("looking up record ...");
            String message = myAthletes.lookupEntry(d, m, y);

        return message;
    }


    public String findAllByDate()
    {
        int m = Integer.parseInt(month.getText());
        int d = Integer.parseInt(day.getText());
        int y = Integer.parseInt(year.getText());
        outputArea.setText("Looking for dates ... ");
        String message = myAthletes.findAllByDate(d, m, y);
        return message;
    }

    //finds the names of the athletes
    public String findRunnerAll()
    {
        String n = name.getText();
        outputArea.setText("looking up record ...");
        String message = myAthletes.findRunnerAll(n); //uses the name value to find the runner
        return message;
    }



    public void blankDisplay() {
        name.setText("");
        day.setText("");
        month.setText("");
        year.setText("");
        hours.setText("");
        mins.setText("");
        secs.setText("");
        dist.setText("");

        activity.setText(""); //////

    }// blankDisplay
    // Fills the input fields on the display for testing purposes only
    public void fillDisplay(Entry ent) {
        name.setText(ent.getName());
        day.setText(String.valueOf(ent.getDay()));
        month.setText(String.valueOf(ent.getMonth()));
        year.setText(String.valueOf(ent.getYear()));
        hours.setText(String.valueOf(ent.getHour()));
        mins.setText(String.valueOf(ent.getMin()));
        secs.setText(String.valueOf(ent.getSec()));
        dist.setText(String.valueOf(ent.getDistance()));

        activity.setText(String.valueOf(ent.getActivity())); ////////
    }

} // TrainingRecordGUI

