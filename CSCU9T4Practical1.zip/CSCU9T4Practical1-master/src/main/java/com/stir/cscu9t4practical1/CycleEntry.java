package com.stir.cscu9t4practical1;


public class CycleEntry extends Entry{
    protected String terrain, speed, activity;

    public CycleEntry(String n, int d, int m, int y, int h, int min, int s, float dist, String terrain, String speed, String activity) {
        super(n, d, m, y, h, min, s, dist);
        this.terrain = terrain; //declaration
        this.speed = speed; //declaration
        this.activity = activity; //declaration

    }


    public String getTerrain(){
        return terrain;
    } //gets terrain

    public String getTempo()
    {
        return speed;
    } //gets speed

    public String getActivity()
    {
        return activity;
    } //gets activity

    @Override //overrides the original entry class
    public String getEntry () {
        String result = getName()+" cycled " + getDistance() + " km in "
                +getHour()+":"+getMin()+":"+ getSec() + " on "
                +getDay()+"/"+getMonth()+"/"+getYear()+ " on " + getTerrain()+ " at " + getTempo()+ " tempo" + "\n";
        return result;
    }

}
